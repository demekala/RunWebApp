﻿namespace RunGroopWebApp.Data.Enum
{
    public enum ClubCategory
    {
        RoadRunner,
        Womens,
        City,
        Trail,
        Endurance
    }
}