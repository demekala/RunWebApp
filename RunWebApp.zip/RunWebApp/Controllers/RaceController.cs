﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RunGroopWebApp.Models;
using RunWebApp.Data;

namespace RunWebApp.Controllers
{
    public class RaceController : Controller
    {
        private readonly ApplicationDBContext _context;

        public RaceController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            List<Race> races = _context.Races.ToList();
            return View(races);
        }

        public IActionResult Detail(int id)
        {
            Race race = _context.Races.Include(a => a.Address).SingleOrDefault(c => c.Id == id);
            return View(race);
        }
    }
}
